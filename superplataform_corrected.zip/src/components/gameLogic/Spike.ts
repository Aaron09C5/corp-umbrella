export class Spike {
  constructor(public x: number, public y: number) {}
}