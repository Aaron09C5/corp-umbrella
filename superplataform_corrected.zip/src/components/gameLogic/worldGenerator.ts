import { Platform } from './Platform';
import { Coin } from './Coin';
import { Enemy } from './Enemy';
import { Spike } from './Spike';

interface DifficultySettings {
  enemyDensity: number;
  spikeDensity: number;
  movingPlatformChance: number;
  gapSize: { min: number, max: number };
}

function getDifficultySettings(score: number): DifficultySettings {
  // Increase difficulty every 100 points
  const level = Math.floor(score / 100);
  return {
    enemyDensity: Math.min(0.7 + (level * 0.02), 0.85), // Max 85% enemy density
    spikeDensity: Math.min(0.2 + (level * 0.01), 0.4), // Max 40% spike density
    movingPlatformChance: Math.min(0.3 + (level * 0.02), 0.5), // Max 50% moving platforms
    gapSize: {
      min: Math.max(150 - (level * 2), 100), // Min gap decreases to 100
      max: Math.max(250 - (level * 2), 200), // Max gap decreases to 200
    }
  };
}

export function generatePlatform(lastX: number, score: number): {
  platform: Platform;
  coins: Coin[];
  enemies: Enemy[];
  spikes: Spike[];
} {
  const difficulty = getDifficultySettings(score);
  
  const minWidth = 400; // Increased minimum width
  const maxWidth = 800; // Increased maximum width
  const minY = 350;
  const maxY = 450;

  const gap = difficulty.gapSize.min + Math.random() * (difficulty.gapSize.max - difficulty.gapSize.min);
  const isMoving = Math.random() < difficulty.movingPlatformChance;
  
  // Moving platforms are smaller
  const width = isMoving 
    ? minWidth / 3 + Math.random() * (maxWidth / 3 - minWidth / 3)
    : minWidth + Math.random() * (maxWidth - minWidth);
    
  const y = minY + Math.random() * (maxY - minY);

  const platform = new Platform(lastX + gap, y, width, 50, isMoving);

  // Generate items
  const coins: Coin[] = [];
  const enemies: Enemy[] = [];
  const spikes: Spike[] = [];
  
  // Calculate sections for item placement
  const sectionWidth = 100; // One item every 100 pixels
  const numberOfSections = Math.floor(width / sectionWidth);
  const totalItems = Math.max(2, numberOfSections - 1); // Ensure at least 2 items, leave edges empty
  
  const numberOfCoins = Math.floor(totalItems * (1 - difficulty.enemyDensity));
  const numberOfEnemies = Math.floor(totalItems * difficulty.enemyDensity);
  
  // Safe zones at platform edges
  const edgeMargin = 80;
  
  // Place coins
  const coinPositions = new Set<number>();
  while (coinPositions.size < numberOfCoins) {
    const position = edgeMargin + Math.floor(Math.random() * (width - 2 * edgeMargin));
    if (!coinPositions.has(position)) {
      let validPosition = true;
      // Check minimum distance from other coins
      for (const existingPos of coinPositions) {
        if (Math.abs(position - existingPos) < 60) {
          validPosition = false;
          break;
        }
      }
      if (validPosition) {
        coinPositions.add(position);
        coins.push(new Coin(platform.x + position, platform.y - 40));
      }
    }
  }

  // Place enemies
  const enemyPositions = new Set<number>();
  while (enemyPositions.size < numberOfEnemies) {
    const position = edgeMargin + Math.floor(Math.random() * (width - 2 * edgeMargin));
    let validPosition = true;

    // Check distance from coins and other enemies
    for (const coin of coins) {
      if (Math.abs((platform.x + position) - coin.x) < 80) {
        validPosition = false;
        break;
      }
    }
    
    for (const existingPos of enemyPositions) {
      if (Math.abs(position - existingPos) < 80) {
        validPosition = false;
        break;
      }
    }

    if (validPosition) {
      enemyPositions.add(position);
      enemies.push(new Enemy(platform.x + position, platform.y - 30));
    }
  }

  // Add spikes with better spacing
  if (!isMoving) { // Only add spikes to non-moving platforms
    const spikePositions = new Set<number>();
    const numberOfSpikeSections = Math.floor(width / 100);
    
    for (let i = 0; i < numberOfSpikeSections; i++) {
      if (Math.random() < difficulty.spikeDensity) {
        const basePosition = platform.x + (i * 100) + 50;
        let validPosition = true;

        // Check distance from coins, enemies, and other spikes
        for (const coin of coins) {
          if (Math.abs(basePosition - coin.x) < 60) {
            validPosition = false;
            break;
          }
        }
        
        for (const enemy of enemies) {
          if (Math.abs(basePosition - enemy.x) < 60) {
            validPosition = false;
            break;
          }
        }

        if (validPosition && basePosition > platform.x + edgeMargin && basePosition < platform.x + width - edgeMargin) {
          spikes.push(new Spike(basePosition, platform.y - 20));
        }
      }
    }
  }

  return { platform, coins, enemies, spikes };
}