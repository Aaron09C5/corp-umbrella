export class Enemy {
  constructor(public x: number, public y: number) {}
}