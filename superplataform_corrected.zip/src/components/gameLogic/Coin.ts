export class Coin {
  constructor(public x: number, public y: number) {}
}