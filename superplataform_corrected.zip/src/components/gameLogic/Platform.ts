export class Platform {
  private moveDirection: number = 1;
  private originalY: number;
  private moveRange: number = 150;
  private moveSpeed: number = 2;

  constructor(
    public x: number, 
    public y: number, 
    public width: number, 
    public height: number,
    public isMoving: boolean = false
  ) {
    this.originalY = y;
  }

  update() {
    if (!this.isMoving) return;

    this.y += this.moveSpeed * this.moveDirection;
    
    if (this.y > this.originalY) {
      this.y = this.originalY;
      this.moveDirection = -1;
    } else if (this.y < this.originalY - this.moveRange) {
      this.y = this.originalY - this.moveRange;
      this.moveDirection = 1;
    }
  }
}