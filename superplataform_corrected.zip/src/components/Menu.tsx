import React, { useState } from 'react';
import { Play, Menu as MenuIcon } from 'lucide-react';

interface MenuProps {
  onStart: (playerName: string) => void;
  highScore: number;
}

export default function Menu({ onStart, highScore }: MenuProps) {
  const [playerName, setPlayerName] = useState('');

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-900 text-white">
      <div className="bg-gray-800 p-8 rounded-lg shadow-xl w-96 max-w-full">
        <h1 className="text-4xl font-bold text-center mb-8">Super Platform</h1>
        
        {highScore > 0 && (
          <div className="text-center mb-6">
            <p className="text-xl">High Score: {highScore}</p>
          </div>
        )}
        
        <div className="mb-6">
          <label htmlFor="playerName" className="block text-sm font-medium mb-2">
            Enter Your Name
          </label>
          <input
            type="text"
            id="playerName"
            value={playerName}
            onChange={(e) => setPlayerName(e.target.value)}
            className="w-full px-4 py-2 rounded bg-gray-700 border border-gray-600 focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50"
            placeholder="Player Name"
          />
        </div>
        
        <button
          onClick={() => onStart(playerName || 'Player')}
          disabled={!playerName.trim()}
          className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 px-6 py-3 rounded-lg font-bold mb-4 transition"
        >
          <Play className="w-5 h-5" />
          Play Game
        </button>
      </div>
    </div>
  );
}