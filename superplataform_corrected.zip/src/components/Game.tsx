import React, { useEffect, useRef, useState } from 'react';
import { Trophy, Heart } from 'lucide-react';
import { Player } from './gameLogic/Player';
import { Platform } from './gameLogic/Platform';
import { Coin } from './gameLogic/Coin';
import { Enemy } from './gameLogic/Enemy';
import { Spike } from './gameLogic/Spike';
import { generatePlatform } from './gameLogic/worldGenerator';

const GAME_HEIGHT = 600;
const GAME_WIDTH = 800;
const GRAVITY = 0.5;
const JUMP_FORCE = -12;
const MOVE_SPEED = 5;
const FALL_THRESHOLD = GAME_HEIGHT + 100;

interface GameProps {
  playerName: string;
  onReturnToMenu: () => void;
}

export default function Game({ playerName, onReturnToMenu }: GameProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(() => {
    const saved = localStorage.getItem('highScore');
    return saved ? parseInt(saved) : 0;
  });
  const [lives, setLives] = useState(3);
  const [gameOver, setGameOver] = useState(false);

  const gameStateRef = useRef({
    player: new Player(100, 300),
    platforms: [new Platform(0, 500, 800, 50, false)],
    coins: [],
    enemies: [],
    spikes: [],
    keys: { a: false, d: false, space: false },
    cameraOffset: 0,
    lastPlatformX: 0,
    isRespawning: false,
  });

  const respawnPlayer = () => {
    const state = gameStateRef.current;
    state.isRespawning = true;

    const visiblePlatforms = state.platforms.filter(platform => 
      platform.x >= state.cameraOffset - 200 && 
      platform.x <= state.cameraOffset + GAME_WIDTH
    );

    if (visiblePlatforms.length > 0) {
      const highestPlatform = [...visiblePlatforms].sort((a, b) => a.y - b.y)[0];
      state.player.x = highestPlatform.x + highestPlatform.width / 2;
      state.player.y = highestPlatform.y - 50;
    } else {
      state.player.x = state.cameraOffset + GAME_WIDTH / 3;
      state.player.y = 300;
    }

    state.player.vx = 0;
    state.player.vy = 0;
    state.player.canJump = true;

    setTimeout(() => {
      state.isRespawning = false;
    }, 1500);
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key.toLowerCase() === 'a') gameStateRef.current.keys.a = true;
      if (e.key.toLowerCase() === 'd') gameStateRef.current.keys.d = true;
      if (e.key === ' ') gameStateRef.current.keys.space = true;
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.key.toLowerCase() === 'a') gameStateRef.current.keys.a = false;
      if (e.key.toLowerCase() === 'd') gameStateRef.current.keys.d = false;
      if (e.key === ' ') gameStateRef.current.keys.space = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    let animationId: number;

    const gameLoop = () => {
      if (gameOver) return;

      const state = gameStateRef.current;
      ctx.clearRect(0, 0, GAME_WIDTH, GAME_HEIGHT);

      // Update moving platforms
      state.platforms.forEach(platform => platform.update());

      if (state.player.y > FALL_THRESHOLD && !state.isRespawning) {
        setLives(l => {
          const newLives = l - 1;
          if (newLives <= 0) {
            setGameOver(true);
            if (score > highScore) {
              setHighScore(score);
              localStorage.setItem('highScore', score.toString());
            }
            return 0;
          }
          respawnPlayer();
          return newLives;
        });
      }

      if (!state.isRespawning) {
        if (state.keys.a) state.player.vx = -MOVE_SPEED;
        if (state.keys.d) state.player.vx = MOVE_SPEED;
        if (!state.keys.a && !state.keys.d) state.player.vx = 0;

        if (state.keys.space && state.player.canJump) {
          state.player.vy = JUMP_FORCE;
          state.player.canJump = false;
        }

        state.player.vy += GRAVITY;
        state.player.x += state.player.vx;
        state.player.y += state.player.vy;
      }

      // Generate new platforms
      if (state.player.x > state.lastPlatformX - 1000) {
        const { platform, coins, enemies, spikes } = generatePlatform(state.lastPlatformX, score);
        state.platforms.push(platform);
        state.coins.push(...coins);
        state.enemies.push(...enemies);
        state.spikes.push(...spikes);
        state.lastPlatformX = platform.x + platform.width;
        
        // Clean up old elements
        const cleanupX = state.cameraOffset - GAME_WIDTH;
        state.platforms = state.platforms.filter(p => p.x + p.width > cleanupX);
        state.coins = state.coins.filter(c => c.x > cleanupX);
        state.enemies = state.enemies.filter(e => e.x > cleanupX);
        state.spikes = state.spikes.filter(s => s.x > cleanupX);
      }

      let onPlatform = false;
      state.platforms.forEach(platform => {
        if (state.player.y + 40 >= platform.y && 
            state.player.y <= platform.y + platform.height &&
            state.player.x + 40 >= platform.x && 
            state.player.x <= platform.x + platform.width) {
          if (state.player.vy > 0) {
            state.player.y = platform.y - 40;
            state.player.vy = 0;
            state.player.canJump = true;
            onPlatform = true;
          }
        }
      });

      if (!onPlatform && state.player.vy === 0) {
        state.player.canJump = false;
      }

      // Collect coins
      state.coins = state.coins.filter(coin => {
        if (Math.abs(state.player.x - coin.x) < 30 && Math.abs(state.player.y - coin.y) < 30) {
          setScore(s => s + 10);
          return false;
        }
        return true;
      });

      // Check collisions with enemies and spikes
      if (!state.isRespawning) {
        const checkCollision = (x: number, y: number) => {
          return Math.abs(state.player.x - x) < 30 && Math.abs(state.player.y - y) < 30;
        };

        const hasCollided = state.enemies.some(enemy => checkCollision(enemy.x, enemy.y)) ||
                          state.spikes.some(spike => checkCollision(spike.x, spike.y));

        if (hasCollided) {
          setLives(l => {
            if (l <= 1) {
              setGameOver(true);
              if (score > highScore) {
                setHighScore(score);
                localStorage.setItem('highScore', score.toString());
              }
              return 0;
            }
            respawnPlayer();
            return l - 1;
          });
        }
      }

      state.cameraOffset = state.player.x - GAME_WIDTH / 3;

      // Render game
      ctx.save();
      ctx.translate(-state.cameraOffset, 0);

      // Draw background
      ctx.fillStyle = '#87CEEB';
      ctx.fillRect(state.cameraOffset, 0, GAME_WIDTH, GAME_HEIGHT);

      // Draw platforms
      state.platforms.forEach(platform => {
        ctx.fillStyle = platform.isMoving ? '#4A90E2' : '#8B4513';
        ctx.fillRect(platform.x, platform.y, platform.width, platform.height);
      });

      // Draw player
      if (state.isRespawning) {
        ctx.globalAlpha = 0.5 + Math.sin(Date.now() / 100) * 0.5;
      }
      ctx.fillStyle = '#FF0000';
      ctx.fillRect(state.player.x, state.player.y, 40, 40);
      ctx.globalAlpha = 1;

      // Draw coins
      ctx.fillStyle = '#FFD700';
      state.coins.forEach(coin => {
        ctx.beginPath();
        ctx.arc(coin.x, coin.y, 10, 0, Math.PI * 2);
        ctx.fill();
      });

      // Draw enemies
      ctx.fillStyle = '#00FF00';
      state.enemies.forEach(enemy => {
        ctx.fillRect(enemy.x, enemy.y, 30, 30);
      });

      // Draw spikes
      ctx.fillStyle = '#808080';
      state.spikes.forEach(spike => {
        ctx.beginPath();
        ctx.moveTo(spike.x - 10, spike.y + 20);
        ctx.lineTo(spike.x, spike.y);
        ctx.lineTo(spike.x + 10, spike.y + 20);
        ctx.closePath();
        ctx.fill();
      });

      // Draw player name
      ctx.fillStyle = '#FFFFFF';
      ctx.font = '16px Arial';
      ctx.fillText(playerName, state.player.x, state.player.y - 10);

      ctx.restore();

      animationId = requestAnimationFrame(gameLoop);
    };

    gameLoop();

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      cancelAnimationFrame(animationId);
    };
  }, [gameOver, highScore, playerName, score]);

  const restartGame = () => {
    gameStateRef.current = {
      player: new Player(100, 300),
      platforms: [new Platform(0, 500, 800, 50, false)],
      coins: [],
      enemies: [],
      spikes: [],
      keys: { a: false, d: false, space: false },
      cameraOffset: 0,
      lastPlatformX: 0,
      isRespawning: false,
    };
    setScore(0);
    setLives(3);
    setGameOver(false);
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-900 p-4">
      <div className="relative">
        <div className="absolute top-4 left-4 flex items-center gap-4 z-10">
          <div className="flex items-center gap-2 bg-white/90 p-2 rounded-lg">
            <Trophy className="w-6 h-6 text-yellow-500" />
            <span className="font-bold">{score}</span>
          </div>
          <div className="flex items-center gap-2 bg-white/90 p-2 rounded-lg">
            <Heart className="w-6 h-6 text-red-500" />
            <span className="font-bold">{lives}</span>
          </div>
        </div>
        <canvas
          ref={canvasRef}
          width={GAME_WIDTH}
          height={GAME_HEIGHT}
          className="border-4 border-white rounded-lg shadow-lg"
        />
        {gameOver && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/70">
            <div className="text-center">
              <h2 className="text-4xl font-bold text-white mb-4">Game Over!</h2>
              <p className="text-xl text-white mb-2">Score: {score}</p>
              <p className="text-xl text-white mb-4">High Score: {highScore}</p>
              <div className="flex gap-4">
                <button
                  onClick={restartGame}
                  className="bg-blue-600 text-white px-6 py-2 rounded-lg font-bold hover:bg-blue-700 transition"
                >
                  Play Again
                </button>
                <button
                  onClick={onReturnToMenu}
                  className="bg-gray-600 text-white px-6 py-2 rounded-lg font-bold hover:bg-gray-700 transition"
                >
                  Main Menu
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
      <div className="mt-4 text-white text-center">
        <p>Use A and D to move, SPACE to jump</p>
      </div>
    </div>
  );
}