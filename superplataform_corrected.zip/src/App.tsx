import { useState } from 'react';
import Game from './components/Game';
import Menu from './components/Menu';

function App() {
  const [gameState, setGameState] = useState<{
    isPlaying: boolean;
    playerName: string;
  }>({
    isPlaying: false,
    playerName: '',
  });

  const startGame = (playerName: string) => {
    setGameState({
      isPlaying: true,
      playerName,
    });
  };

  const returnToMenu = () => {
    setGameState({
      isPlaying: false,
      playerName: '',
    });
  };

  const highScore = parseInt(localStorage.getItem('highScore') || '0');

  return (
    <div className="min-h-screen bg-gray-900">
      {gameState.isPlaying ? (
        <Game playerName={gameState.playerName} onReturnToMenu={returnToMenu} />
      ) : (
        <Menu onStart={startGame} highScore={highScore} />
      )}
    </div>
  );
}

export default App;